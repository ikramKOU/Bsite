import {createLogger, format, transports } from 'winston';

const {combine, timestamp, printf} = format;

const logFormat = printf(({level, message, timestamp}) => {
    return `${level} / ${timestamp}: ${message}`;
});

const logger = createLogger({
    format: combine(
        timestamp({format:'DD-MM-YYYY HH:mm:ss'}),
        logFormat,
    ),
    transports:[
        new transports.File({ filename: 'error.log', level: 'error' }),
    ]
});

export default logger;