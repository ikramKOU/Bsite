import prisma from "@/lib/prisma";
import { NextAuthOptions } from "next-auth";
import CredentialsProvider from 'next-auth/providers/credentials';
import GoogleProvider from 'next-auth/providers/google';

export const authOptions: NextAuthOptions = {
    secret: process.env.NEXTAUTH_SECRET,
    session: { strategy: 'jwt' },
    // adapter: PrismaAdapter(prisma),
    // adapter: PrismaAdapter(prisma),
    debug: process.env.NODE_ENV === 'development',
    pages: {
        signIn: '/auth'
    },
    callbacks: {
        async redirect(params) {
            return params.baseUrl;
        },
        async jwt(params) {
            if(params.user && params.user.id) {
                const user = await prisma.auth.findUnique({
                    where: {
                        id:Number(params.user.id),
                    },
                    select: {
                        role:true,
                    }
                });
                // params.token.id = user.id;
                if(user) {
                    params.token.role = user?.role;
                }
            }
            // else return null;
            return params.token;
        },
        async session({session, user, token}) {
            if(session.user) {
                session.user.role = token.role;
            }
            return session;
        },
    },
    // callbacks: {
    //     async signIn(params) {
    //         // You can access user, account, profile, email, credentials from params
    //         const { user, account, profile, email, credentials } = params;

    //         // Your existing signIn logic here
    //         return Promise.resolve(true);
    //     },

    //     async redirect(params) {
    //         return Promise.resolve(params.url);
    //     },
    //     async session(params) {
    //         return Promise.resolve(params.session);
    //     },
    //     async jwt(params) {
    //         return Promise.resolve(params.token);
    //     },

    // },
    providers: [
        // GoogleProvider({
        //     clientId: process.env.GOOGLE_CLIENT_ID as string,
        //     clientSecret: process.env.GOOGLE_CLIENT_SECRET as string,
        //     profile(profile, tokens) {
        //         return {
        //             id:0,
                    
        //         }
        //     },
        // }),
        CredentialsProvider({
            name: 'Credentials',
            credentials: {
                email: { label: 'Email', type: 'email' },
                password: { label: 'Password', type: 'password' },
            },
            async authorize(credentials) {
                // console.log('getting the user');
                const user = await prisma.auth.findUnique({
                    where: {
                        email: credentials?.email,
                        password: credentials?.password
                    },
                    select: {
                        role:true,
                        email:true,
                        id:true,
                    }
                });

                if (!user) {
                    return null;
                }

                return {
                    id: String(user.id),
                    email: user.email,
                    // password: user.password,
                    role:user.role,
                };
            },
        }),
    ],
}