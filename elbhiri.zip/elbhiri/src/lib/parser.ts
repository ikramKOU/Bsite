import { NextApiRequest, NextApiResponse } from 'next';

type MiddlewareFunction = (
    req: NextApiRequest,
    res: NextApiResponse,
    next: (err?: any) => void
) => void;

export default function initMiddleware(
    req: NextApiRequest,
    res: NextApiResponse,
    middleware: MiddlewareFunction
) {
    return new Promise<void>((resolve, reject) => {
        middleware(req, res, (result: any) => {
            if (result instanceof Error) {
                return reject(result);
            }
            resolve();
        });
    });
}