import { NextResponse } from "next/server";


export const response = (status:number, message:any) => {
    return NextResponse.json({message:message}, {status:status});
}
