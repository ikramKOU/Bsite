// import { NextRequest, NextApiResponse } from 'next';
import type { NextRequest } from 'next/server';
import { response } from '../../utils';
import logger from '@/lib/winston';
import prisma from '@/lib/prisma';
import { authOptions } from '@/lib/auth';
import {getServerSession} from 'next-auth/next';
// import { EUserRoles } from '@/interfaces/User';

enum ERoles {
    PATRON='PATRON',
    HEAD_CONTABLE='HEAD_CONTABLE',
    CONTABLE='CONTABLE',
    CUSTOMER='CUSTOMER',
}

export async function POST(
    req: NextRequest,
) {
    try {
        const session = await getServerSession(authOptions);
        if(session) return response(401, "already logged-in");
        const {email, password} = await req.json();

        const exists = await prisma.auth.findUnique({
            where: {
                email:email
            }
        });

        if(exists) return response(409, "bad request");

        const user = await prisma.auth.create({
            data: {
                email: email,
                password: password,
                role: ERoles.CUSTOMER,
            }
        });

        if(user) return response(200, "success");
        else return response(500, "internal server error");

    } catch (error) {
        if(error instanceof Error) {
            logger.error(error);
        }
        return response(500, 'internal server error');
    }
}