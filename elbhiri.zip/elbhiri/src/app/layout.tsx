import { useSelectedLayoutSegments } from 'next/navigation';
import './globals.css';
import { Inter } from 'next/font/google';
import NextAuthProvider from '@/lib/SessionProvider';
import { ReactNode } from 'react';
const inter = Inter({ subsets: ['latin'] });

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className={`inter.className`}>
        <NextAuthProvider>
          <section>
            <div className="grow">{children}</div>
          </section>
        </NextAuthProvider>
      </body>
    </html>
  );
}