import React from 'react';
//import { FaHome, FaEnvelope, FaCog } from 'react-icons/fa';
import Sidebar from '../../components/Dashboard/Sidebar';
import NavBar  from '../../components/Dashboard/NavBar';
import Cards from '../../components/Dashboard/Cards';
import march from '../../components/marches/march';
import TableFournisseur from '@/src/components/tables/TableFournisseur';

export default function Home() {
  return (
    <div className='flex flex-col min-h-screen'>
      <NavBar />    
        <div className='flex flex-row gap-2'>
          
        <Sidebar /> 
        <Cards /> 
        </div>
      


 
       </div>
  
  )
}



