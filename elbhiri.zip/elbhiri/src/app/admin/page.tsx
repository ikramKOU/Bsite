import { ok } from 'assert';
import React from 'react';

export default function AdminPage() {
  return (
    <>
      <h1 className="admin-header">ADMIN PAGE!</h1>
    </>
  );
}


