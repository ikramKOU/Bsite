"use server"

import { Input } from '../../../components/ui/input';

import axios from 'axios';
import React, { FormEvent } from 'react'

export default async function RegisterPage() {

    

    const postData = () => {
        const fet = async () => {
            const x = await axios.post('/api/auth/register', {email:'ok@gmail.com', password:"okker"});
            if(x.status === 200) {
                console.log('registered');
            }
            else {
                console.log('error');
            }
        }
        fet();
    }

    return (
        <>
            <main className='bg-white h-screen flex justify-center items-center'>
                <form method="post">
                    <Input name="email" type="email" customStyle='text-red' placeholder='Enter your email'/>
                    <Input name="password" type="password" customStyle='text-red' placeholder='Enter your password' />
                    <Input name="login" type="button" placeholder='Login'/>
                    {/* <Input typee="button" /> */}
                </form>
            </main>
        </>
    )
}
