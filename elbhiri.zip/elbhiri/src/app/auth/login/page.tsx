"use server"
<<<<<<<< HEAD:elbhiri/src/app/auth/login/page.tsx
import Login from '../../../components/login/Login'
========
>>>>>>>> 9b8e47ecea5aeb6ecbc77f2a733d779ccdcdd5af:elbhiri/src/app/auth/page.tsx
import React from 'react'
import { AuthForm } from '@/components/Forms/AuthForm'

export default async function LoginPage() {

  return (
    <>
        <AuthForm/>
    </>
  )
}
