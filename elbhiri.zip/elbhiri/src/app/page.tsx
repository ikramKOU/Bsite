"use client";
import React from 'react';
<<<<<<< HEAD:elbhiri/src/app/page.tsx
//import { FaHome, FaEnvelope, FaCog } from 'react-icons/fa';
import Login from '../components/login/Login';


export default function page() {
  return (
    <>
      <Login />      
       </>
  
  )
=======
import {useSession} from 'next-auth/react';

export default function IndexPage() {

    const {data:session} = useSession();

    return (
      <div>
        {
          <div>
            {
              
            }
          </div>
        }
      </div>
    
    )
>>>>>>> 9b8e47ecea5aeb6ecbc77f2a733d779ccdcdd5af:elbhiri/app/page.tsx
}



