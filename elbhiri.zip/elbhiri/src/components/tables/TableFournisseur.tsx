import React from 'react'

function TableFournisseur() {
  return (
    <div>
      <h1> la table de fournissuer</h1>
    </div>
  )
}

export default TableFournisseur
