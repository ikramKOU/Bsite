import React from 'react'

function TableOpe() {
  return (
    <div>
      <h1>Tables des operation</h1>
    </div>
  )
}

export default TableOpe
