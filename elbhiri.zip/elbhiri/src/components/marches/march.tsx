import React from 'react';
import Cards from '../Dashboard/Cards';


const Marches: React.FC = () => {
  return (
    <div>
      <h1>Marchés</h1>
      <Cards />
    </div>
  );
};

export default Marches;