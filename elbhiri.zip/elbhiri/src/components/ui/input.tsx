"use client";
import React, { ChangeEvent, useState } from 'react'

interface IInputProps {
    name:string;
    type:string;
    customStyle?:string;
    placeholder?:string;
}

export const Input:React.FC<IInputProps> = (props) => {
    const [val, setVal] = useState<string>('');
    const handleChange = (e:ChangeEvent<HTMLInputElement>) => {
        e.preventDefault();
        setVal(e.target.value);
        console.log(e.target.type);
    }
    return (
        <>
            <div>
                <input name={`${props.name}`} type={`${props.type}`} value={val} onChange={handleChange} className={`${props.customStyle}`} placeholder={`${props.placeholder}`} key={`${props.placeholder}`}/>
            </div>
        </>
    )
}
