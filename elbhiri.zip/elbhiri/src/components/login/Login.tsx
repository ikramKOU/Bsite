"use client"
import React, { ChangeEvent, useState } from 'react';
import "./login.css";
//import Dash from '../Dashboard/dash';
import Sidebar from '../Dashboard/Sidebar';
import NavBar from '../Dashboard/NavBar';
import Cards from '../Dashboard/Cards';
import { signIn } from 'next-auth/react';
import logger from '../../lib/winston';
import Link from  'next/link' 

const Login = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setemail] = useState<string>('');
  const [pass, setpass] = useState<string>('');

  const handleLogin = () => {

    const fetch = async () => {
      try {
        const result = await signIn('credentials', {
          email: email,
          password: pass,
          redirect: true,
        });

        // console.log('Sign in result:', result);
      } catch (error) {
        if (error instanceof Error) {
          // logger.error(error);
        }
        // console.error('Sign in error:', error);
      }
    }
    fetch();

  }

  const toggleSignUp = () => {
    setIsSignUp((prev) => !prev);
  };

  return (
    <main className='flex h-screen justify-center items-center'>
      <div className={`cont rounded-md ${isSignUp ? 's--signup' : ''}`}>
        <div className="form sign-in">
          <h2>Bienvenue de retour,</h2>
          <form>
            <label>
              <span>Entrez votre Email</span>
              <input type="email" onChange={(e: ChangeEvent<HTMLInputElement>) => setemail(e.target.value)} />
            </label>
            <label>
              <span>Entrez votre mot de passe</span>
              <input type="password" onChange={(e: ChangeEvent<HTMLInputElement>) => setpass(e.target.value)} />
            </label>
            <p className="forgot-pass">mot de passe oublié?</p>
            <button type="button" className="submit" onClick={handleLogin}>
              Se connecter
            </button>



          </form>
        </div>

        <div className="sub-cont">
          <div className="img">
            <div className="img__text m--up">
              <h2>Nouveau ici ?</h2>
              <p>Inscrivez-vous et découvrez de nombreuses nouvelles opportunités!</p>
            </div>
            <div className="img__text m--in">
              <h2>Un de nous?</h2>
              <p>Si vous avez déjà un compte, connectez-vous simplement. Vous nous avez manqué!</p>
            </div>
            <div className="img__btn" onClick={toggleSignUp}>

              
                <span className="m--up">
                  sign-in
                </span>
             


              <span className="m--in">
                sign-up
              </span>
            </div>
          </div>

          <div className="form sign-up">
            <h2>
              Dans un monde numérique, l`utilisation en ligne est le moyen moderne de préserver nos forêts, une
              clic à la fois.
            </h2>
            <label>
              <span>saisie votre nom</span>
              <input type="text" />
            </label>
            <label>
              <span>saisie votre Email</span>
              <input type="email" />
            </label>
            <label>
              <span>saisie votre mot de passe</span>
              <input type="password" />
            </label>
            <button type="button" className="submit">
            <Link href="/dashboard">sign-in</Link>
            </button>
            <button type="button" className="fb-btn">
              Rejoignez-nous avec <span>facebook</span>
            </button>
          </div>
        </div>
      </div>

    </main>
  );
};

export default Login;
