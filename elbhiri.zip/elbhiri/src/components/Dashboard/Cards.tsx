import React from 'react'
interface ServiceCardProps {
    color: string;
    title: string;
    description: string;
  }
  
  const ServiceCard: React.FC<ServiceCardProps> = ({ color, title, description }) => {
    return (
      <div className={`w-full mb-10 sm:mb-0 sm:w-1/2 hover:scale-110 transition-ease-in-out delay-150 duration-300 cursor-pointer `}>
        
        <div className={`relative h-full ml-0 mr-0 sm:mr-10 `}>
        <span className={`absolute top-0 left-0 w-full h-full mt-1 ml-1 bg-${color}-500 rounded-lg`}></span>
          <div className={`relative h-full p-5 bg-white border-2 border-${color}-500 rounded-lg`}>
            <div className={`flex items-center -mt-1`}>
              <h3 className={`my-2  text-lg font-bold text-gray-800`}>{title}</h3>
            </div>
           
            <p className={`mb-2 text-gray-600 `}>{description}</p>
          </div>
        </div>
      </div>
    );
  };
function Cards() {
  return (
    <div>
        
        <div className="container bg-voilet-300 relative flex flex-col justify-between  max-w-6xl px-5 mx-auto xl:px-0 mt-4">
          <div className='flex justify-between item-center '>
      <h2 className="mb-3 text-3xl font-extrabold leading-tight text-gray-900">Mes marchés</h2>
      <button className='transition ease-in-out delay-150 bg-blue-500 hover:-translate-y-1 hover:scale-110 hover:bg-indigo-500 duration-300 p-2 rounded-full px-4 text-yellow-900 font-bold 'style={{ backgroundColor:"#DED0B6", borderRadius:"10%"}}>Add Project</button>
          </div>
      <p className="mb-3 text-lg text-gray-500">Volia notre differents projet de cette année</p>
      <div className="w-full">
        <div className="flex flex-col w-full mb-4 sm:flex-row ">
          <ServiceCard
            color="indigo"
            title="Hotel Pyramid"
            description="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident sapiente ab eligendi ipsam tempora blanditiis accusantium est labore iusto laborum?"
          />
          <ServiceCard
            color="indigo"
            title="Appartements hotel "
            description="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident sapiente ab eligendi ipsam tempora blanditiis accusantium est labore iusto laborum?"
          />
       
        </div>
        <div className="flex flex-col w-full mb-5 sm:flex-row">
          <ServiceCard
            color="indigo"
            title="Chef SARA "
            description="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident sapiente ab eligendi ipsam tempora blanditiis accusantium est labore iusto laborum?"
          />
          <ServiceCard
            color="indigo"
            title="Time square Club"
            description="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident sapiente ab eligendi ipsam tempora blanditiis accusantium est labore iusto laborum?"
          />
          <ServiceCard
            color="indigo"
            title="Drougerie"
            description="Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident sapiente ab eligendi ipsam tempora blanditiis accusantium est labore iusto laborum?"
          />
        </div>
      </div>
    </div>
    </div>
  )
}

export default Cards
