
import React from 'react';
import 'bootstrap-icons/font/bootstrap-icons.css';
import 'bootstrap/dist/css/bootstrap.css'
import Link from 'next/link'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser } from '@fortawesome/free-solid-svg-icons';
import '@fortawesome/fontawesome-free/css/all.css';
import logo from '../Dashboard/logo_elbhiri.png';
import Image from 'next/image';

const NavBar: React.FC = () => {
    return (
        <>

<nav className="navbar navbar-expand-lg navbar-dark" style={{ backgroundColor: '#b37400' }}>
<Image
          className="w-25 h-20 rounded-lg"
          src={logo}
          alt="user photo"
        />
      <div className="container-fluid d-flex justify-content-end">
        <div className="dropdown dropdown-bottom " style={{ marginRight: '10px'}}>
        <div tabIndex={0} role="button" className="btn m-2" style={{ backgroundColor:"#DED0B6", borderRadius:"50%"}}>
        <img
          src="https://tse4.mm.bing.net/th?id=OIP.7bVNCitvVDBjwX7tSYsYOwHaHa&pid=Api&P=0&h=180" 
          alt="Avatar"
          className="rounded-full h-8 w-8 object-cover flex-col"
        />
      </div>

          <ul tabIndex={0} className="dropdown-content z-[1] menu p-2 shadow bg-base-100 rounded-box w-52">
            <li><a>Log out</a></li>
          </ul>
        </div>
      </div>
    </nav>

        </>
    );
};

export default NavBar;

