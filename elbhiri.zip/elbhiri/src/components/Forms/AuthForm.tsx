"use client"
import React, { ChangeEvent, FormEvent, useEffect, useState } from 'react';
import { signIn, signOut } from 'next-auth/react';
import axios from 'axios';
import {useSession} from 'next-auth/react';
import { useRouter } from 'next/router';
import "@/components/styles/auth.css";

export const AuthForm = () => {
    const [isSignUp, setIsSignUp] = useState(false);
    const [email, setemail] = useState<string>('');
    const [pass, setpass] = useState<string>('');
    const [repass, setrepass] = useState<string>('');
    const {data:session} = useSession();
    // const router = useRouter();

    const handleLogin = (e:FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        const fetch = async () => {
            try {
                await signIn('credentials', {
                    email: email,
                    password: pass,
                    redirect: false,
                });

                // console.log('Sign in result:', result);
            } catch (error) {
                if (error instanceof Error) {
                    // logger.error(error);
                }
                // console.error('Sign in error:', error);
            }
        }
        fetch();
    }

    const handleRegister = () => {
        const fetch = async() => {
            try {
                const ax = await axios.post('/api/auth/register', {email:email, password:pass, repassword:repass}, {headers:{"Content-Type":"application/json"}, withCredentials:true});
                if(ax.status === 200) {
                    console.log('success');
                }
                else {
                    console.log('error');
                }
            } catch(error) {
                if(error instanceof Error) {

                }
            }
        }
        fetch();
    }

    const toggleSignUp = () => {
        setIsSignUp((prev) => !prev);
        setemail('');
        setpass('');
        setrepass('');
    };

    return (
        <>
            {
                !session ? (
                    <main className='flex h-screen justify-center items-center'>
                        <div className={`cont rounded-md ${isSignUp ? 's--signup' : ''}`}>
                            <div className="form sign-in">
                                <h2>Bienvenue de retour,</h2>
                                <form onSubmit={handleLogin}>
                                    <label>
                                        <span>Entrez votre Email</span>
                                        <input type="email" onChange={(e: ChangeEvent<HTMLInputElement>) => setemail(e.target.value)} />
                                    </label>
                                    <label>
                                        <span>Entrez votre mot de passe</span>
                                        <input type="password" onChange={(e: ChangeEvent<HTMLInputElement>) => setpass(e.target.value)} />
                                    </label>
                                    <p className="forgot-pass">mot de passe oublié?</p>
                                    <button type="submit" className="submit">
                                        Se connecter
                                    </button>
                                </form>
                            </div>
            
                            <div className="sub-cont">
                                <div className="img">
                                    <div className="img__text m--up">
                                        <h2>Nouveau ici ?</h2>
                                        <p>Inscrivez-vous et découvrez de nombreuses nouvelles opportunités!</p>
                                    </div>
                                    <div className="img__text m--in">
                                        <h2>Un de nous?</h2>
                                        <p>Si vous avez déjà un compte, connectez-vous simplement. Vous nous avez manqué!</p>
                                    </div>
                                    <div className="img__btn" onClick={toggleSignUp}>
                                        <span className="m--up">
                                            sign-in
                                        </span>
                                        <span className="m--in">
                                            sign-up
                                        </span>
                                    </div>
                                </div>
            
                                <div className="form sign-up">
                                    <h2>
                                        Dans un monde numérique, l`utilisation en ligne est le moyen moderne de préserver nos forêts, une
                                        clic à la fois.
                                    </h2>
                                    <label>
                                        <span>saisie votre Email</span>
                                        <input name="email" type="email" onChange={(e:ChangeEvent<HTMLInputElement>) => setemail(e.target.value)}/>
                                    </label>
                                    <label>
                                        <span>saisie votre mot de passe</span>
                                        <input name="password" type="password" onChange={(e: ChangeEvent<HTMLInputElement>) => setpass(e.target.value)} />
                                    </label>
                                    <label>
                                        <span>saisie votre mot de passe</span>
                                        <input name="repassword" type="password" onChange={(e: ChangeEvent<HTMLInputElement>) => setrepass(e.target.value)} />
                                    </label>
                                    <button type="button" className="submit" onClick={handleRegister}>
                                        sign-in
                                    </button>
                                </div>
                            </div>
                        </div>
            
                    </main>

                ) : (
                    <div>{session.user.role}</div>
                )
            }
        </>
    );
}
