"use server"
import React from 'react'
import {signIn} from 'next-auth/react'

export const LoginForm = () => {

    const handleLoginSubmit = () => {
        signIn("credentials", {
            
        })
    }

    return (
        <>
            <form onSubmit={handleLoginSubmit}>

            </form>
        </>
    )
}
