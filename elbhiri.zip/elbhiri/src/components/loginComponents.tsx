"use client"

import axios from 'axios';
import React, {ChangeEvent, FormEvent, useState} from 'react'
import { signIn } from 'next-auth/react'

export default function LoginComponents() {
    const [data, setData] = useState({
        email:'',
        password:'',
    });
    // const [password, setPassword] = useState<string>('');

    const handleEmailChange = (e: ChangeEvent<HTMLInputElement>) => {
        setData({
            ...data, // Spread the existing data
            [e.target.name]: e.target.value, // Update the specific field
        });
        console.log(data.email)
    };

    const handlePasswordChange = (e: ChangeEvent<HTMLInputElement>) => {
        setData({
            ...data, // Spread the existing data
            [e.target.name]: e.target.value, // Update the specific field
        });
        console.log(data.password)
    };

    const handleLogin = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        signIn("credentials", {
            ...data,
            redirect: false,
        })
    };

    return (
        <main className='text-black flex flex-wrap w-72 gap-3'>
            <form method='POST' onSubmit={() => handleLogin}>
                <input
                    className='w-full'
                    type="email"
                    placeholder='Enter your email'
                    value={data.email}
                    onChange={handleEmailChange}
                />
                <input
                    className='w-full'
                    type="password"
                    placeholder='Enter your password'
                    value={data.password}
                    onChange={handlePasswordChange}
                />
                <button>Login</button>

            </form>
        </main>
    )
}
