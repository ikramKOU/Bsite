import React from 'react'

function graph() {
  return (
    <div>
      <h1> les analyses de ce mois</h1>
    </div>
  )
}

export default graph
 